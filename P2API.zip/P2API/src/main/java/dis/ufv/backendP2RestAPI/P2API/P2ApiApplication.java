package dis.ufv.backendP2RestAPI.P2API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P2ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(P2ApiApplication.class, args);
	}

}
