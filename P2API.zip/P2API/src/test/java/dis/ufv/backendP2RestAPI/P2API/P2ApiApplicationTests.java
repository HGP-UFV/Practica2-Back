package dis.ufv.backendP2RestAPI.P2API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P2ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
